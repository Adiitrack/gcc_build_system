
Author:-  Aditya Gaurav
Date  :-  17-09-2021

Project Descriptions:-

This program analyze an array of unsigned char data items and report analytics on the maximum, minimum, mean, and median of the data set.  

Compilation Guidelines:-

To compile and run this code you can run the following commands:-
 $ gcc -o stats.out stats.c
 $ ./stats.out
